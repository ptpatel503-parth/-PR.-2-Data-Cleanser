# # Patient Health Records: Data Preprocessing & Feature Engineering
# 
# **Objective:** Practice missing-value analysis and imputation, outlier detection/treatment, and preparation of a machine-learning-ready dataset for heart-disease risk prediction.
# 
# > The CSV supplied with this project is a **synthetic teaching dataset**, not real patient data. Do not use it for clinical decisions.
# 
# ## Dataset columns
# - `patient_id`: unique identifier
# - `age`, `gender`, `region`: demographic features
# - `bmi`, `blood_pressure`, `cholesterol`, `glucose`: medical measurements
# - `disease_risk`: target (0 = Low Risk, 1 = High Risk); retained unchanged
# 
# ## Setup
# Run the cells from top to bottom. Install packages if required with:
# `pip install pandas numpy matplotlib seaborn scikit-learn scipy jupyter`


import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.experimental import enable_iterative_imputer  # noqa: F401
from sklearn.impute import IterativeImputer
from sklearn.preprocessing import OrdinalEncoder

RANDOM_STATE = 42
DATA_PATH = "patient_health_records.csv"

df = pd.read_csv(DATA_PATH)
print("Dataset shape:", df.shape)
display(df.head())
df.info()


# ## 1. Initial data inspection

print("Duplicate rows:", df.duplicated().sum())
print("Duplicate patient IDs:", df["patient_id"].duplicated().sum())
print("\nData types:")
display(df.dtypes.to_frame("dtype"))
print("\nDescriptive statistics:")
display(df.describe(include="all").T)


# ## 2. Missing-value analysis and summary report

missing_count = df.isna().sum()
missing_percent = (missing_count / len(df) * 100).round(2)
missing_report = pd.DataFrame({
    "missing_count": missing_count,
    "missing_percentage": missing_percent
}).sort_values("missing_percentage", ascending=False)
display(missing_report)

ax = missing_report["missing_percentage"].sort_values().plot(
    kind="barh", figsize=(8, 5), title="Missing values by column (%)"
)
ax.set_xlabel("Missing values (%)")
plt.tight_layout()
plt.show()


# ## 3. Prepare features and protect the target
# 
# `patient_id` is an identifier, not a predictive feature. `disease_risk` is the target and is never imputed or modified. Imputation is fitted on predictor columns only.
# 
# We compare the required approaches on copies of the same incomplete predictor data:
# 1. Simple imputation: median for numeric variables and most frequent for categorical variables.
# 2. Most-frequent categorical imputation.
# 3. Missing indicator + random-sample imputation.
# 4. KNN imputation for numeric features.
# 5. MICE (IterativeImputer) for numeric features.
# 
# Categorical variables are imputed with their mode for the KNN/MICE comparison because these estimators operate on numeric arrays in this implementation.


numeric_cols = ["age", "bmi", "blood_pressure", "cholesterol", "glucose"]
categorical_cols = ["gender", "region"]
feature_cols = numeric_cols + categorical_cols
X_incomplete = df[feature_cols].copy()
y = df["disease_risk"].copy()  # unchanged target

# A. Simple Imputer: median for numeric, most frequent for categorical
simple_num = SimpleImputer(strategy="median")
simple_cat = SimpleImputer(strategy="most_frequent")
X_simple = X_incomplete.copy()
X_simple[numeric_cols] = simple_num.fit_transform(X_incomplete[numeric_cols])
X_simple[categorical_cols] = simple_cat.fit_transform(X_incomplete[categorical_cols])

# B. Most frequent imputation (categorical columns; numeric mode shown for comparison)
mode_imputer = SimpleImputer(strategy="most_frequent")
X_mode = pd.DataFrame(
    mode_imputer.fit_transform(X_incomplete),
    columns=feature_cols, index=df.index
)

# C. Missing indicators + random sample imputation
X_random = X_incomplete.copy()
missing_indicators = X_incomplete.isna().astype(int).add_suffix("_was_missing")
for col in feature_cols:
    miss = X_random[col].isna()
    observed = X_random.loc[~miss, col].dropna().to_numpy()
    if miss.any():
        X_random.loc[miss, col] = np.random.default_rng(RANDOM_STATE).choice(
            observed, size=miss.sum(), replace=True
        )
X_random = pd.concat([X_random, missing_indicators], axis=1)

# D. KNN imputation for numeric columns; mode for categorical columns
X_knn = X_incomplete.copy()
X_knn[numeric_cols] = KNNImputer(n_neighbors=5, weights="distance").fit_transform(
    X_incomplete[numeric_cols]
)
X_knn[categorical_cols] = simple_cat.fit_transform(X_incomplete[categorical_cols])

# E. MICE / IterativeImputer for numeric columns; mode for categorical columns
X_mice = X_incomplete.copy()
mice = IterativeImputer(random_state=RANDOM_STATE, max_iter=10)
X_mice[numeric_cols] = mice.fit_transform(X_incomplete[numeric_cols])
X_mice[categorical_cols] = simple_cat.fit_transform(X_incomplete[categorical_cols])

imputation_comparison = pd.DataFrame({
    "method": ["Simple (median/mode)", "Most frequent", "Random sample",
               "KNN (numeric + mode categorical)", "MICE (numeric + mode categorical)"],
    "remaining_missing_values": [
        X_simple.isna().sum().sum(),
        X_mode.isna().sum().sum(),
        X_random[feature_cols].isna().sum().sum(),
        X_knn.isna().sum().sum(),
        X_mice.isna().sum().sum()
    ]
})
display(imputation_comparison)
display(X_simple.head())


# ### 3.1 Compare imputed numeric distributions
# 
# The plots compare the original observed values with values produced by each numeric imputation strategy. Imputed values are not expected to reproduce the exact original values; the purpose is to assess whether the resulting distributions are plausible.


for col in numeric_cols:
    plt.figure(figsize=(8, 4))
    sns.kdeplot(df[col].dropna(), label="Observed", fill=False)
    sns.kdeplot(X_simple[col], label="Simple median", fill=False)
    sns.kdeplot(X_knn[col], label="KNN", fill=False)
    sns.kdeplot(X_mice[col], label="MICE", fill=False)
    plt.title(f"Distribution comparison: {col}")
    plt.legend()
    plt.tight_layout()
    plt.show()


# ## 4. Outlier detection
# 
# The assignment asks for Z-score, IQR, and percentile detection, followed by Winsorization. These methods are applied to the numeric measurement columns. Detection is performed after a baseline imputation so that missing values do not break the calculations.
# 
# - **Z-score:** flags values with absolute z-score greater than 3.
# - **IQR:** flags values below Q1 − 1.5×IQR or above Q3 + 1.5×IQR.
# - **Percentile:** flags values outside the 1st and 99th percentiles.
# - **Winsorization:** caps values at the 1st and 99th percentiles rather than deleting rows.
# 
# Thresholds are configurable and should be justified for a real dataset with domain experts.


# Use median-imputed numeric data as a consistent baseline for detection
baseline = X_simple[numeric_cols].copy()

def zscore_flags(series, threshold=3):
    sd = series.std(ddof=0)
    if sd == 0 or pd.isna(sd):
        return pd.Series(False, index=series.index)
    z = (series - series.mean()) / sd
    return z.abs() > threshold

def iqr_flags(series, multiplier=1.5):
    q1, q3 = series.quantile([0.25, 0.75])
    iqr = q3 - q1
    return (series < q1 - multiplier * iqr) | (series > q3 + multiplier * iqr)

def percentile_flags(series, lower=0.01, upper=0.99):
    lo, hi = series.quantile([lower, upper])
    return (series < lo) | (series > hi)

outlier_counts = {}
for method, detector in {
    "Z-score": zscore_flags,
    "IQR": iqr_flags,
    "Percentile (1st-99th)": percentile_flags
}.items():
    outlier_counts[method] = {
        col: int(detector(baseline[col]).sum()) for col in numeric_cols
    }

outlier_report = pd.DataFrame(outlier_counts).T
display(outlier_report)


# ### 4.1 Visualize outliers using boxplots

for col in numeric_cols:
    plt.figure(figsize=(8, 3))
    sns.boxplot(x=baseline[col])
    plt.title(f"Boxplot before treatment: {col}")
    plt.tight_layout()
    plt.show()


# ## 5. Outlier treatment and before-vs-after comparison
# 
# For comparison, this notebook creates:
# - `iqr_filtered`: rows with at least one IQR-flagged numeric value removed.
# - `percentile_capped`: values capped at the 1st/99th percentiles.
# - `winsorized`: a separate copy using the same percentile capping (Winsorization).
# 
# The final dataset uses Winsorization to preserve the number of patient records. This is a demonstration choice, not a claim that capping is always clinically appropriate.


# IQR row-removal version for comparison
iqr_row_flags = pd.DataFrame(
    {col: iqr_flags(baseline[col]) for col in numeric_cols}
)
rows_to_remove = iqr_row_flags.any(axis=1)
iqr_filtered = X_simple.loc[~rows_to_remove].copy()

# Percentile capping / Winsorization
lower_bounds = baseline[numeric_cols].quantile(0.01)
upper_bounds = baseline[numeric_cols].quantile(0.99)

percentile_capped = X_simple.copy()
winsorized = X_simple.copy()
for col in numeric_cols:
    percentile_capped[col] = percentile_capped[col].clip(
        lower=lower_bounds[col], upper=upper_bounds[col]
    )
    winsorized[col] = winsorized[col].clip(
        lower=lower_bounds[col], upper=upper_bounds[col]
    )

before_after = pd.DataFrame({
    "before": baseline.describe().loc[["mean", "std", "min", "50%", "max"]].stack(),
    "after_winsorization": winsorized[numeric_cols].describe().loc[
        ["mean", "std", "min", "50%", "max"]
    ].stack()
})
display(before_after)
print("Original rows:", len(df))
print("Rows after IQR row removal:", len(iqr_filtered))
print("Rows retained after Winsorization:", len(winsorized))


# ### 5.1 Boxplots after Winsorization

for col in numeric_cols:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3))
    sns.boxplot(x=baseline[col], ax=axes[0])
    axes[0].set_title("Before")
    sns.boxplot(x=winsorized[col], ax=axes[1])
    axes[1].set_title("After Winsorization")
    fig.suptitle(col)
    plt.tight_layout()
    plt.show()


# ## 6. Final cleaned dataset
# 
# The final version uses median imputation for numeric features, most-frequent imputation for categorical features, and percentile Winsorization for numeric measurements. The target remains unchanged. The identifier is retained for record traceability but excluded from the model feature list.
# 
# For a production ML workflow, fit all imputers and outlier thresholds on the training split only, then apply the fitted transformations to validation/test data to avoid data leakage.


final_clean = df[["patient_id"]].copy()
final_clean[feature_cols] = X_simple[feature_cols].copy()

for col in numeric_cols:
    final_clean[col] = final_clean[col].clip(
        lower=lower_bounds[col], upper=upper_bounds[col]
    )

final_clean["disease_risk"] = y  # target copied without changes

final_missing = final_clean.isna().sum()
print("Final dataset shape:", final_clean.shape)
print("Remaining missing values:", int(final_missing.sum()))
print("Target unchanged:", final_clean["disease_risk"].equals(df["disease_risk"]))
display(final_clean.head())
display(final_clean.describe(include="all").T)

final_clean.to_csv("patient_health_records_cleaned.csv", index=False)


# ## 7. Final validation and export

validation = pd.DataFrame({
    "missing_values": final_clean.isna().sum(),
    "data_type": final_clean.dtypes.astype(str)
})
display(validation)

print("Duplicate patient IDs:", final_clean["patient_id"].duplicated().sum())
print("Target values:", sorted(final_clean["disease_risk"].unique()))
print("Target distribution:")
display(final_clean["disease_risk"].value_counts().rename("count").to_frame())

# A compact profiling summary
profile = pd.DataFrame({
    "column": df.columns,
    "missing_before": [df[c].isna().sum() for c in df.columns],
    "missing_after": [final_clean[c].isna().sum() for c in df.columns]
})
display(profile)


# ## 8. Brief project report / interpretation
# 
# **Imputation strategy:** Median imputation is robust to skew and extreme observations, while most-frequent imputation is suitable for categorical fields. KNN and MICE use relationships among numeric variables and are useful comparison methods, but require careful scaling, validation, and training-only fitting in a real predictive workflow. Random-sample imputation preserves the observed marginal distribution better than a constant fill, and missingness indicator columns retain information about which values were absent.
# 
# **Outlier handling:** Z-score is straightforward when distributions are approximately normal but is sensitive to extreme values. IQR is more robust to skew. Percentile capping and Winsorization retain all rows while limiting the influence of extreme values. The best method depends on whether an extreme measurement is an error or a genuine clinical observation.
# 
# **Dataset usability:** The final exported CSV has no missing predictor values, preserves patient IDs and the original binary target, and limits extreme numeric measurements through capping. The dataset is suitable for demonstrating downstream preprocessing and model-building workflows, but it is synthetic and not suitable for clinical use.
# 
# **Important limitation:** No single imputation/outlier method is universally best. Compare methods using domain knowledge and downstream validation metrics, not only the number of missing values or outliers removed.

