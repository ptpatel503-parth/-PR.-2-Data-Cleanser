# Patient Health Records – Data Preprocessing & Feature Engineering

## Files
- `patient_health_records.csv`: synthetic raw dataset containing missing values and injected extreme values.
- `Patient_Health_Data_Preprocessing.ipynb`: complete notebook with analysis, imputation, outlier detection/treatment, plots, validation and export.
- `Patient_Health_Data_Preprocessing.py`: script version of the notebook workflow.
- `Project_Report.docx`: ready-to-edit project report.

## Run
1. Install Python 3.9+ and the packages:
   `pip install pandas numpy matplotlib seaborn scikit-learn scipy jupyter`
2. Keep the notebook and CSV in the same folder.
3. Open the notebook:
   `jupyter notebook Patient_Health_Data_Preprocessing.ipynb`
4. Run all cells in order.
5. The notebook creates `patient_health_records_cleaned.csv`.

## Dataset
500 synthetic patient records; fields: patient_id, age, gender, region, bmi, blood_pressure, cholesterol, glucose, disease_risk.
`disease_risk` is a binary target (0 = Low Risk, 1 = High Risk) and is not imputed.

**Disclaimer:** This is fabricated educational data, not real patient information and not for diagnosis or clinical decisions.
